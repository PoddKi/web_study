export const TicTacToe = {
  el: null,

  isGameEnd: false,

  isXTurn: true,

  matrix: [
    [null, null, null],
    [null, null, null],
    [null, null, null],
  ],


  wonCombinations: [
    [[1, 1], [1, 2], [1, 3]],
    [[2, 1], [2, 2], [2, 3]],
    [[3, 1], [3, 2], [3, 3]],
    [[1, 1], [2, 2], [3, 3]],
    [[1, 3], [2, 2], [3, 1]],
    [[1, 1], [2, 1], [3, 1]],
    [[1, 2], [2, 2], [3, 2]],
    [[1, 3], [2, 3], [3, 3]],
  ],

  /**
   * Функция инициализации элементов и запуска игры
   * @returns {object} - текущий объект
   */
  init({el, onMove}) {
    this.el = el
    this.onMove = onMove
    this.boxes = el.querySelectorAll('.tic-tac-toe__ceil')
    
    return this
  },
  
  /**
   * Функция инициализации слушателей события клика по ячейке
   */
  initListeners() {
    this.boxes.forEach(box => {
      box.addEventListener('click', event => {
        if (
          this.isGameEnd || 
          !this.isBlockEmpty(event.target)
        ) {
          return
        }

        this.setBlockValue(event.target)
        this.setBlockDom(event.target)
        
        if (this.checkForWin()) {
          this.setGameEndStatus()
        }

        if (!this.checkHasEmptyBlocks()) {
          this.setGameEndStatus()

          setTimeout(() => {
            alert('Конец игры: Ничья')
          })
          return
        }

        if (this.isGameEnd) {
          setTimeout(() => {
            alert('Конец игры: Победил ' + this.getCurrentTurnValue())
          })
        } else {
          this.changeTurnValue()
          if (this.onMove) {
            this.onMove(this.isXTurn)
          }
        }
      })
    })
  },

  /**
   * Проверка на наличие пустых блоков
   * @returns {boolean} - true если есть пустые блоки, false - если нет
   */
  checkHasEmptyBlocks() {
    return this.matrix.some(row => row.some(cell => cell === null));
  },

  /**
   * Инициализация слушателя клика и вызов колбэка текущего хода
   */
  startGame() {
    this.initListeners();
    this.onMove(this.isXTurn);
  },

  /**
   * Сброс данных и очищение дом дерева
   */
  restartGame() {
    this.isGameEnd = false;
    this.isXTurn = true;
    this.matrix = [
      [null, null, null],
      [null, null, null],
      [null, null, null],
    ];
    this.boxes.forEach(box => (box.innerText = ''));
    this.onMove(this.isXTurn);
  },
  
  /**
   * Проверка пустой ли блок
   * @param {HTMLDivElement} target - ячейка в дом дереве
   * @returns {boolean} - true если блок пустой
   */
  isBlockEmpty(target) {
    const [row, col] = this.getBlockPosition(target)
    
    return !this.matrix[row - 1][col - 1]
  },

  /**
   * Получение позиции блока из dataset
   * @param {HTMLDivElement} target - ячейка в дом дереве
   * @returns {array} - массив со строкой и колонкой target вида [row, col]
   */
  getBlockPosition(target) {
    const {row, col} = target.dataset
    
    return [row, col]
  },
  
  /**
   * Изменение значения элемента в матрице
   * Определяет значение [row, col] ячейки, после чего устанавливает
   * значение в матрице для соответствующего поля
   * @param {HTMLDivElement} target - ячейка в дом дереве
   * @param {boolean?} clear - если true - отчистить ячейку в матрице
   */
  setBlockValue(target, clear = false) {
    const [row, col] = this.getBlockPosition(target);
    this.matrix[row - 1][col - 1] = clear ? null : this.getCurrentTurnValue();
  },

  /**
   * Изменение значения элемента в дом дереве
   * Определяет текущий ход, после чего устанавливает
   * значение в дом дереве
   * @param {HTMLDivElement} target - ячейка в дом дереве
   * @param {boolean?} clear - если true - отчистить target
   */
  setBlockDom(target, clear = false) {
    target.innerText = clear ? '' : this.getCurrentTurnValue();
  },

  /**
   * Получение строки с текущем ходом
   * @returns {string} Текущий ход 'X' или 'O'
   */
  getCurrentTurnValue() {
    return this.isXTurn ? 'X' : 'O';
  },

  /**
   * Изменение текущего хода в данных
   */
  changeTurnValue() {
    this.isXTurn = !this.isXTurn;
  },

  /**
   * Проверка победных комбинаций
   * @returns {boolean} - true если кто-то победил
   */
  checkForWin() {    
    for (let i = 0; i < this.wonCombinations.length; i++) {
      const [first, second, third] = this.wonCombinations[i]

      if (
        this.matrix[first[0] - 1][first[1] - 1] &&
        this.matrix[first[0] - 1][first[1] - 1] === this.matrix[second[0] - 1][second[1] - 1] &&
        this.matrix[third[0] - 1][third[1] - 1] === this.matrix[second[0] - 1][second[1] - 1]
      ) {
        return true
      }
    }

    return false
  },

  /**
   * Установить статус об окончании игры
   */
  setGameEndStatus() {
    this.isGameEnd = true;
  }
}